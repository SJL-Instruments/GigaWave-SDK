class TriggerError(Exception): pass
